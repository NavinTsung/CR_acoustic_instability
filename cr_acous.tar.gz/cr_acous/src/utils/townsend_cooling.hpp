#ifndef COOLING_HPP
#define COOLING_HPP

//========================================================================================
// Athena++ astrophysical MHD code
// Copyright(C) 2014 James M. Stone <jmstone@princeton.edu> and other code contributors
// Licensed under the 3-clause BSD License, see LICENSE file for details
//========================================================================================
//! \file townsend_cooling.hpp

#include "../athena.hpp"
#include "../athena_arrays.hpp"

class Cooling {
public:
  Cooling(Real Tfloor, Real Tceil, Real T_0, Real L_0, Real epsil);
  ~Cooling();

  Real T_floor, T_ceil, T_0;
  Real L_c, L_h, L_0;
  Real epsilon;

  Real townsend(Real temp, Real rho, Real const dt);
  Real heating(Real heat_coef, Real const dt);

private:
  Real gg, gg1;

  int nbins;
  Real T_N, coef_N;

  AthenaArray<Real> cool_t;
  AthenaArray<Real> cool_tef;
  AthenaArray<Real> cool_coef;
  AthenaArray<Real> cool_index;
};

#endif // COOLING_CLASS
