//========================================================================================
// Athena++ astrophysical MHD code
// Copyright(C) 2014 James M. Stone <jmstone@princeton.edu> and other code contributors
// Licensed under the 3-clause BSD License, see LICENSE file for details
//========================================================================================
//! \file townsend_cooling.cpp

#include <cmath>      // sqrt
#include <algorithm>  // min

#include "../athena.hpp"
#include "../athena_arrays.hpp"
#include "townsend_cooling.hpp"

// Initialize all values in the cooling table
Cooling::Cooling(Real Tfloor, Real Tceil, Real T0, Real L0, Real epsil) {
  gg = 5./3.;
  gg1 = gg/(gg - 1.);

  T_floor = Tfloor;
  T_ceil = Tceil;
  T_0 = T0;
  L_0 = L0; 
  epsilon = epsil;
  L_c = L_0*pow(T_floor/T_0, epsilon);
  L_h = L_0*pow(T_ceil/T_0, epsilon);

  // Initialize the cooling table
  nbins = 2;

  cool_t.NewAthenaArray(nbins);
  cool_tef.NewAthenaArray(nbins);
  cool_coef.NewAthenaArray(nbins);
  cool_index.NewAthenaArray(nbins);

  // Temperatures in code unit
  cool_t(0) = T_floor;
  cool_t(1) = T_ceil;

  // Cooling Coefficient [1e-23 ergs*cm3/s]
  cool_coef(0) = L_c;
  cool_coef(1) = L_h;

  // Cooling power index
  cool_index(0) = epsilon;
  cool_index(1) = 0.0;

  // Get reference temperature and cooling efficiency
  T_N = cool_t(nbins-1);
  coef_N = cool_coef(nbins-1);

  // Calculate All TEFs Y_k recursively (Eq. A6)
  cool_tef(nbins-1) = 0.0; // Last Y_N = 0
  
  for (int i=nbins-2; i>=0; i--) {
    Real t_i = cool_t(i);
    Real t_ip1 = cool_t(i+1);
    Real coef_i = cool_coef(i);
    Real slope = cool_index(i);

    Real sm1 = slope - 1.;

    // Case for slope = 1 doesn't exist so don't need to consider
    Real step = (coef_N/coef_i)*(t_i/T_N)*(std::pow(t_i/t_ip1, sm1) - 1.)/sm1;
    cool_tef(i) = cool_tef(i+1) - step;
  }

} // End constructor

Cooling::~Cooling() {
  cool_t.DeleteAthenaArray();
  cool_tef.DeleteAthenaArray();
  cool_coef.DeleteAthenaArray();
  cool_index.DeleteAthenaArray();
}

// Exact Integration Scheme for Radiative Cooling from Townsend (2009)
// Returns: Temperature(K) at the next timestep after cooling
// Requires: - Input temperature, density, and timestep in cgs units
//           - T < t_ceil and T > t_floor
//           - All cooling slopes are not equal to 1
Real Cooling::townsend(Real temp, Real rho, Real const dt)
{
  // Check that temperature is above the cooling floor and below ceiling
  if (temp < T_floor) return T_floor;
  if (temp > T_ceil) return T_ceil;

  // Get the index of the right temperature bin
  int idx = 0;
  while ((idx < nbins-2) && (cool_t(idx+1) < temp)) { idx += 1; }

  // Look up the corresponding slope and coefficient
  Real t_i   = cool_t(idx);
  Real tef_i = cool_tef(idx);
  Real coef  = cool_coef(idx);
  Real slope = cool_index(idx);

  // Compute the Temporal Evolution Function Y(T) (Eq. A5)
  Real sm1 = slope - 1.;
  Real tef = tef_i + (coef_N/coef)*(t_i/T_N)*(std::pow(t_i/temp, sm1) - 1.)/sm1;

  // Compute the adjusted TEF for new timestep (Eqn. 26)
  Real tef_adj = tef + (gg - 1.)*rho*coef_N*dt/T_N;

  // TEF is a strictly decreasing function and new_tef > tef
  // Check if the new TEF falls into a lower bin
  // If so, update slopes and coefficients
  while ((idx > 0) && (tef_adj > cool_tef(idx))) {
    idx -= 1;
    t_i   = cool_t(idx);
    tef_i = cool_tef(idx);
    coef  = cool_coef(idx);
    slope = cool_index(idx);
  }

  // Compute the Inverse Temporal Evolution Function Y^{-1}(Y) (Eq. A7)
  Real oms  = 1. - slope;
  Real tnew = t_i*std::pow(1. - oms*(coef/coef_N)*(T_N/t_i)*(tef_adj - tef_i), 1./oms);

  // Return the new temperature if it is still above the temperature floor
  //return std::max(tnew,tfloor);
  return tnew;
}

// Adds a heating term via simple explicit first order scheme 
// For constant heating this should be exact
// Returns the change in temperature, should be positive(heating)
Real Cooling::heating(Real heat_coef, Real const dt) 
{
  return dt*(gg - 1.)*heat_coef;
}

