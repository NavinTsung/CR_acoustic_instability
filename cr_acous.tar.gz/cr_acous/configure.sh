#!/bin/bash
python configure.py --prob cr_power_v2_fixFc -b -cr -mpi -hdf5 --hdf5_path /usr/local/Cellar/hdf5-parallel/1.12.0 

