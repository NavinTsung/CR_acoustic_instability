# Import installed packages
import numpy as np 
import numpy.linalg as LA
import numpy.polynomial.polynomial as poly
import matplotlib.pyplot as plt 
import matplotlib.gridspec as gs
import matplotlib.legend as lg
import matplotlib.colors as colours
from matplotlib.ticker import (MultipleLocator, FormatStrFormatter, AutoMinorLocator, LogFormatter)
from scipy import interpolate
import h5py

# Matplotlib default param
plt.rcParams['font.size'] = 8
plt.rcParams['legend.fontsize'] = 8
plt.rcParams['legend.loc'] = 'best'
plt.rcParams['lines.linewidth'] = 1.
plt.rcParams['lines.markersize'] = 0.7
plt.rcParams['mathtext.fontset'] = 'stix'
plt.rcParams['font.family'] = 'STIXGeneral'

def plotdefault():
  plt.rcParams.update(plt.rcParamsDefault)
  plt.rcParams['font.size'] = 12
  plt.rcParams['legend.fontsize'] = 12
  plt.rcParams['legend.loc'] = 'best'
  plt.rcParams['lines.linewidth'] = 1.5
  plt.rcParams['lines.markersize'] = 2.
  plt.rcParams['mathtext.fontset'] = 'stix'
  plt.rcParams['font.family'] = 'STIXGeneral'
  return

def latexify(columns=2, square=False, num_fig=0):
  """
  Set up matplotlib's RC params for LaTeX plotting.
  Call this before plotting a figure.
  Parameters
  ----------
  columns : {1, 2}
  """
  assert(columns in [1, 2])

  fig_width_pt = 240.0 if (columns == 1) else 504.0
  inches_per_pt = 1./72.27 # Convert pt to inch
  golden_mean = (np.sqrt(5.) - 1.)/2. 
  square_size = 0.8
  fig_width = fig_width_pt*inches_per_pt # Width in inches
  fig_height = fig_width*golden_mean
  if square:
    fig_height = fig_width*square_size # Height in inches
  if num_fig != 0:
    fig_height = fig_width/num_fig
  fig_size = [fig_width, fig_height]

  font_size = 10 if columns == 1 else 8

  plt.rcParams['pdf.fonttype'] = 42
  plt.rcParams['ps.fonttype'] = 42
  plt.rcParams['font.size'] = font_size
  plt.rcParams['axes.labelsize'] = font_size
  plt.rcParams['axes.titlesize'] = font_size
  plt.rcParams['xtick.labelsize'] = font_size
  plt.rcParams['ytick.labelsize'] = font_size
  plt.rcParams['legend.fontsize'] = font_size
  plt.rcParams['figure.figsize'] = fig_size
  plt.rcParams['figure.titlesize'] = 12
  return 

# Global parameters
gc = 4./3.
gg = 5./3.
gc1 = gc/(gc - 1.)
gg1 = gg/(gg - 1.)
tiny_number = 1.e-10
big_number = 1.e20



def beta_m(beta):
	m = np.sqrt(2./(gg*beta))
	return m

def alpha_c(alpha):
	c = np.sqrt(gc*alpha/gg)
	return c

def growth(m, c, kl, forward=False):
	if forward:
		growth = -(0.5*c**2/kl)*(1. - m/2)*(1. + (gg - 1.)*m)
		if growth < 0:
			growth = 0.
	else:
		growth = -(0.5*c**2/kl)*(1. + m/2)*(1. - (gg - 1.)*m)
		if growth < 0:
			growth = 0.
	return growth 

def hybrid(m, c, kl):
	p4 = 1.
	p3 = -(m + 1j*kl)
	p2 = -(1. + c**2)
	p1 = (m + 1j*kl) - (gg - 3./2.)*m*c**2 
	p0 = 0.5*(gg - 1.)*m**2*c**2 

	solve = poly.polyroots([p0, p1, p2, p3, p4])
	if np.all(np.imag(solve) >= 0):
		most_unstable = 0.
	else:
		most_unstable = -np.amin(np.imag(solve))
	return most_unstable

def propagate(m, c, kl):
	p4 = 1.
	p3 = -(m + 1j*kl)
	p2 = -(1. + c**2)
	p1 = (m + 1j*kl) - (gg - 3./2.)*m*c**2 
	p0 = 0.5*(gg - 1.)*m**2*c**2 

	solve = poly.polyroots([p0, p1, p2, p3, p4])
	if np.all(np.imag(solve) >= 0):
		most_unstable_propagate = 0.
	else:
		index = np.argmin(np.imag(solve))
		most_unstable_propagate = np.abs(np.real(solve[index]))
	return most_unstable_propagate

def ratio(m, c, kl, forward=False):
	p0 = 1.
	p1 = -(m + 1j*kl)
	p2 = -(1. + c**2)
	p3 = (m + 1j*kl) - (gg - 3./2.)*m*c**2 
	p4 = 0.5*(gg - 1.)*m**2*c**2 

	solve = np.roots([p0, p1, p2, p3, p4])
	if np.all(np.imag(solve) >= 0):
		most_unstable = 0.
	else:
		most_unstable = -np.amin(np.imag(solve))

	if forward:
		growth = -(0.5*c**2/kl)*(1. - m/2)*(1. + (gg - 1.)*m)
		if growth < 0:
			growth = 0.
	else:
		growth = -(0.5*c**2/kl)*(1. + m/2)*(1. - (gg - 1.)*m)
		if growth < 0:
			growth = 0.

	if (most_unstable == 0) or (growth == 0):
		ratio = 0 
	else:
		ratio = most_unstable/growth

	return ratio 

beta = np.logspace(0, -2, 100)
alpha = np.logspace(-1, 2, 100)
m = np.sqrt(2./(gg*beta))
c = np.sqrt(gc*alpha/gg)
kl = np.array([0.01, 0.1, 1., 10., 100., 1000.])

growth_rate = np.zeros((np.size(kl), np.size(m), np.size(c)))
hybrid_rate = np.zeros((np.size(kl), np.size(m), np.size(c)))
hybrid_propagate = np.zeros((np.size(kl), np.size(m), np.size(c)))
ratio_rate = np.zeros((np.size(kl), np.size(m), np.size(c)))

for i, kkl in enumerate(kl):
	for j, mm in enumerate(m):
		for k, cc in enumerate(c):
			print(kkl, mm, cc)
			growth_rate[i, j, k] = growth(mm, cc, kkl, forward=False)
			hybrid_rate[i, j, k] = hybrid(mm, cc, kkl)
			hybrid_propagate[i, j, k] = propagate(mm, cc, kkl)
			ratio_rate[i, j, k] = ratio(mm, cc, kkl, forward=False)

plotdefault()

fig1 = plt.figure()
fig2 = plt.figure()
fig3 = plt.figure()
fig4 = plt.figure() 
fig5 = plt.figure() 
fig6 = plt.figure() 
fig7 = plt.figure()
fig = [fig1, fig2, fig3, fig4, fig5, fig6, fig7]
ax1 = fig1.add_subplot(111)
ax2 = fig2.add_subplot(111)
ax3 = fig3.add_subplot(111)
ax4 = fig4.add_subplot(111)
ax5 = fig5.add_subplot(111)
ax6 = fig6.add_subplot(111)
ax7 = fig7.add_subplot(111)
ax = [ax1, ax2, ax3, ax4, ax5, ax6, ax7] 



m_mesh, c_mesh = np.meshgrid(m, c)
beta_mesh, alpha_mesh = np.meshgrid(beta, alpha)

# for i, kkl in enumerate(kl): 
# 	# ax1.contour(m, c, np.transpose(growth_rate[i, :]), levels=[1.e-3], linewidths=3.)
# 	# ax2.contour(m, c, np.transpose(hybrid_rate[i, :]), levels=[1.e-3], linewidths=3.)
# 	img1 = ax1.pcolormesh(m, c, np.transpose(growth_rate[i, :]), norm=colours.LogNorm(), cmap='bwr')
# 	img2 = ax2.pcolormesh(m, c, np.transpose(hybrid_rate[i, :]), norm=colours.LogNorm(), cmap='bwr')
# 	img3 = ax3.pcolormesh(m, c, np.transpose(growth_rate[i, :]), norm=colours.LogNorm(), cmap='bwr')
# 	img = [img1, img2, img3]

which_kl = -4

factor1 = 0.5*np.cbrt(0.5*m_mesh*c_mesh**2*(gg - 1.))
factor2 = (np.sqrt(3.)/2.)*np.cbrt(0.5*m_mesh**2*c_mesh**2*(gg - 1.)/kl[which_kl])
factor3 = m_mesh 
factor4 = 1.

curve1 = 16*gg/((gg - 1.)*gc)*np.sqrt(gg*beta/2.)
curve2 = 8.*gg**2*kl[which_kl]*beta/(3**(3./2.)*gc*(gg - 1.))

ax1.contour(beta_mesh, alpha_mesh, np.transpose(growth_rate[which_kl, :]), levels=[1.e-10], linewidths=3.)
ax2.contour(beta_mesh, alpha_mesh, np.transpose(hybrid_rate[which_kl, :]), levels=[1.e-2], linewidths=3.)
ax4.contour(beta_mesh, alpha_mesh, np.transpose(hybrid_propagate[which_kl, :])/factor1, levels=[0.9, 1.1], linewidths=3.)
ax5.contour(beta_mesh, alpha_mesh, np.transpose(hybrid_propagate[which_kl, :])/factor2, levels=[0.9, 1.1], linewidths=3.)
ax6.contour(beta_mesh, alpha_mesh, np.transpose(hybrid_propagate[which_kl, :])/factor3, levels=[0.9, 1.1], linewidths=3.)
ax7.contour(beta_mesh, alpha_mesh, np.transpose(hybrid_propagate[which_kl, :])/factor4, levels=[0.9, 1.1], linewidths=3.)
img1 = ax1.pcolormesh(beta_mesh, alpha_mesh, np.transpose(growth_rate[which_kl, :]), norm=colours.LogNorm(), cmap='bwr')
img2 = ax2.pcolormesh(beta_mesh, alpha_mesh, np.transpose(hybrid_rate[which_kl, :]), norm=colours.LogNorm(), cmap='bwr')
img3 = ax3.pcolormesh(beta_mesh, alpha_mesh, np.transpose(ratio_rate[which_kl, :]), norm=colours.LogNorm(), cmap='bwr')
img4 = ax4.pcolormesh(beta_mesh, alpha_mesh, np.transpose(hybrid_propagate[which_kl, :])/factor1, cmap='bwr', norm=colours.LogNorm())
img5 = ax5.pcolormesh(beta_mesh, alpha_mesh, np.transpose(hybrid_propagate[which_kl, :])/factor2, cmap='bwr', norm=colours.LogNorm())
img6 = ax6.pcolormesh(beta_mesh, alpha_mesh, np.transpose(hybrid_propagate[which_kl, :])/factor3, cmap='bwr', norm=colours.LogNorm())
img7 = ax7.pcolormesh(beta_mesh, alpha_mesh, np.transpose(hybrid_propagate[which_kl, :])/factor4, cmap='bwr', norm=colours.LogNorm())
img = [img1, img2, img3, img4, img5, img6, img7]

# ax4.loglog(beta, curve1, 'k--', linewidth=3.)
# ax5.loglog(beta, curve2, 'k--', linewidth=3.)

for i, axes in enumerate(ax):
	axes.set_xscale('log')
	axes.set_yscale('log')
	axes.set_xlabel('$\\beta$')
	axes.set_ylabel('$\\alpha$')

fig4.colorbar(img4, ax=ax4, label='Hybrid nondiff')
fig5.colorbar(img5, ax=ax5, label='Hybrid diff')
fig6.colorbar(img6, ax=ax6, label='Alfven')
fig7.colorbar(img7, ax=ax7, label='Acoustic')

for i, figu in enumerate(fig):
	if (figu == fig1) or (figu == fig2):
		figu.colorbar(img[i], ax=ax[i], label='$\\Gamma/k c_s$')
	elif figu == fig3:
		figu.colorbar(img[i], ax=ax[i], label='Ratio')
	else:
		pass
	figu.tight_layout()
	figu.savefig('./growth{}.png'.format(i), dpi=300)

plt.show()